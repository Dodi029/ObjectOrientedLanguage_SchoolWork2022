#include <iostream>
#include <string>
#include "Screen.h"
#include "TicketBox.h"
using namespace std;

int main() {
	TUKoreaTBox tBox;
	Screen* screen = NULL;
	bool bScreenMenu = true;
	int select = 0;

	tBox.Initialize();
	while (1)
	{
		if (bScreenMenu) {
			screen = tBox.selectMenu();
			bScreenMenu = false;
			if (!screen) return 0;
		}
		screen->showMovieMenu();
		cout << "�޴��� �����ϼ���:";
		cin >> select; cout << endl;
		switch (select)
		{
		case 1:
			screen->showMovieInfo();
			break;
		case 2:
			screen->showSeatMap();
			break;
		case 7:
			bScreenMenu = true;
			break;
		default:
			break;
		}
	}
}